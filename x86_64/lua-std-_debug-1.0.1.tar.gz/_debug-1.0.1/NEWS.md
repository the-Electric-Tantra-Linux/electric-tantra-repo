# Stdlib NEWS - User visible changes

## Noteworthy changes in release 1.0.1 (2018-09-22) [stable]

### New Features

  - Initial support for Lua 5.4.


## Noteworthy changes in release 1.0 (2017-10-14) [stable]

### New features (since lua-stdlib-41.2)

  - Initial release, now separated out from lua-stdlib.

  - An entirely new API, which does not use global `_DEBUG` at all.
