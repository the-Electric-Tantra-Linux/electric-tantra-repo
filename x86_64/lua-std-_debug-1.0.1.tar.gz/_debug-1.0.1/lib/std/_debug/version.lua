return "Debug hints library / 1.0.1"
