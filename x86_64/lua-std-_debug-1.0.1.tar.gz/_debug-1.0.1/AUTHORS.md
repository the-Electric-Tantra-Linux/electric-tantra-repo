# `std._debug`'s contributors

This file lists major contributors to `std._debug`. If you think you
should be on it, please raise a [github][] issue. Thanks also to all
those who contribute bug fixes, suggestions and support.

Gary V. Vaughan maintains `std._normalize`, having rewritten and
reorganised the original code from [lua-stdlib][], in addition to
to adding new functionality.

Reuben Thomas started the standard libraries project, which included the
original implementation of some of the functions now distributed with
this package.

[github]: https://github.com/lua-stdlib/_debug/issues
[lua-stdlib]: https://github.com/lua-stdlib/lua-stdlib
