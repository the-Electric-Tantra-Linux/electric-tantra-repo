# normalize's contributors

This file lists major contributors to _normalize_. If you think you
should be on it, please raise a [github][] issue. Thanks also to all
those who have contributed bug fixes, suggestions and support.

Gary V. Vaughan now maintains _normalize_, having rewritten and
reorganised all the original code from [lua-stdlib][], in addition to
to adding a lot of new functionality.

Reuben Thomas started the standard libraries project, which included the
original implementation of many of the functions now distributed with
this package.

[github]: https://github.com/lua-stdlib/normalize/issues
[lua-stdlib]: https://github.com/lua-stdlib/lua-stdlib
