local s = "some text"
   .. "some other"
return s
