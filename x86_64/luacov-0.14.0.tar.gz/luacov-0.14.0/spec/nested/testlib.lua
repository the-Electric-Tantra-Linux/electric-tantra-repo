local a = 1
local b = 2

local lib = {}

function lib.f1()
   local c = 3
   return 4
end

function lib.f2()
   local d = 5
   return 6
end

return lib
