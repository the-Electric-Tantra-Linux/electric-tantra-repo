local testlib = require "testlib"
testlib.f1()
testlib.f2()
testlib.f2()
osexit()
