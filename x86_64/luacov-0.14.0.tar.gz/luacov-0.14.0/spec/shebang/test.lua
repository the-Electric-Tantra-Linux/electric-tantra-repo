#!/usr/bin/env lua
if 10 > 100 then
   local msg = "I don't think this line will execute."
else
   local msg = "Hello, LuaCov!"
end
